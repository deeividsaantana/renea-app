// src/components/layout/AppLayout.jsx

import Navbar from './Navbar';

export default function AppLayout({ children }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar />
      <main
        style={{
          flex: 1,
          maxWidth: 'var(--renea-largura-conteudo-max)',
          width: '100%',
          margin: '0 auto',
          padding: 'var(--renea-space-6) var(--renea-space-5)',
        }}
      >
        {children}
      </main>
    </div>
  );
}
