// src/components/layout/Navbar.jsx
//
// Barra de navegação principal, presente em todas as telas autenticadas.
// Usa o logo na versão "original" (texto branco) sobre fundo verde
// institucional, conforme seção 2.1 da especificação.

import { NavLink, useNavigate } from 'react-router-dom';
import Logo from '../common/Logo';
import { useAuth } from '../../contexts/AuthContext';
import { logout } from '../../services/authService';
import { PERFIL_LABELS } from '../../config/constants';
import './Navbar.css';

const LINKS = [
  { to: '/', label: 'Painel', somenteAdmin: false },
  { to: '/lancamento', label: 'Novo lançamento', somenteAdmin: false },
  { to: '/relatorios', label: 'Relatórios', somenteAdmin: false },
  { to: '/administracao', label: 'Administração', somenteAdmin: true },
];

export default function Navbar() {
  const { perfilUsuario, isAdmin } = useAuth();
  const navigate = useNavigate();

  async function handleSair() {
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <header className="renea-navbar">
      <div className="renea-navbar__conteudo">
        <div className="renea-navbar__marca">
          <Logo fundo="escuro" altura={32} />
        </div>

        <nav className="renea-navbar__links" aria-label="Navegação principal">
          {LINKS.filter((link) => !link.somenteAdmin || isAdmin).map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) =>
                `renea-navbar__link ${isActive ? 'renea-navbar__link--ativo' : ''}`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="renea-navbar__usuario">
          {perfilUsuario && (
            <div className="renea-navbar__usuario-info">
              <span className="renea-navbar__usuario-nome">{perfilUsuario.nome}</span>
              <span className="renea-navbar__usuario-perfil">
                {PERFIL_LABELS[perfilUsuario.perfil] || perfilUsuario.perfil}
              </span>
            </div>
          )}
          <button type="button" className="renea-navbar__sair" onClick={handleSair}>
            Sair
          </button>
        </div>
      </div>
    </header>
  );
}
