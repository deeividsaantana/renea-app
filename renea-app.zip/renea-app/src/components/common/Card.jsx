// src/components/common/Card.jsx

export default function Card({ children, className = '', padding = 'var(--renea-space-5)', ...props }) {
  return (
    <div
      className={`renea-card ${className}`}
      style={{
        backgroundColor: 'var(--renea-branco)',
        border: '1px solid var(--renea-cinza-borda)',
        borderRadius: 'var(--renea-radius-lg)',
        boxShadow: 'var(--renea-sombra-sm)',
        padding,
      }}
      {...props}
    >
      {children}
    </div>
  );
}
