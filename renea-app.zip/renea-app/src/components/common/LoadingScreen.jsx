// src/components/common/LoadingScreen.jsx

import Logo from './Logo';

export default function LoadingScreen() {
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 'var(--renea-space-4)',
        backgroundColor: 'var(--renea-branco)',
      }}
    >
      <Logo fundo="claro" altura={40} />
      <div
        aria-label="Carregando"
        role="status"
        style={{
          width: 28,
          height: 28,
          border: '3px solid var(--renea-cinza-borda)',
          borderTopColor: 'var(--renea-verde-institucional)',
          borderRadius: '50%',
          animation: 'renea-spin 0.7s linear infinite',
        }}
      />
      <style>{`
        @keyframes renea-spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
