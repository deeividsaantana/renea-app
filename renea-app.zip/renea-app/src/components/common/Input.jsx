// src/components/common/Input.jsx

import './Input.css';

/**
 * Campo de formulário padrão com label e mensagem de erro.
 */
export default function Input({
  label,
  erro,
  id,
  className = '',
  containerClassName = '',
  ...props
}) {
  const inputId = id || label?.toLowerCase().replace(/\s+/g, '-');

  return (
    <div className={`renea-campo ${containerClassName}`}>
      {label && (
        <label htmlFor={inputId} className="renea-campo__label">
          {label}
        </label>
      )}
      <input
        id={inputId}
        className={`renea-campo__input ${erro ? 'renea-campo__input--erro' : ''} ${className}`}
        aria-invalid={!!erro}
        aria-describedby={erro ? `${inputId}-erro` : undefined}
        {...props}
      />
      {erro && (
        <span id={`${inputId}-erro`} className="renea-campo__erro" role="alert">
          {erro}
        </span>
      )}
    </div>
  );
}
