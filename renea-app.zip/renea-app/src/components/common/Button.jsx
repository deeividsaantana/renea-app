// src/components/common/Button.jsx

import './Button.css';

/**
 * @param {'primario' | 'secundario' | 'perigo' | 'texto'} variante
 * @param {'sm' | 'md' | 'lg'} tamanho
 */
export default function Button({
  children,
  variante = 'primario',
  tamanho = 'md',
  carregando = false,
  disabled = false,
  type = 'button',
  className = '',
  ...props
}) {
  return (
    <button
      type={type}
      disabled={disabled || carregando}
      className={`renea-btn renea-btn--${variante} renea-btn--${tamanho} ${className}`}
      {...props}
    >
      {carregando ? (
        <span className="renea-btn__spinner" aria-hidden="true" />
      ) : null}
      <span className={carregando ? 'renea-btn__label--oculta' : ''}>{children}</span>
    </button>
  );
}
