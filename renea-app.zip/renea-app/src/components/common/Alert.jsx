// src/components/common/Alert.jsx

const ESTILOS = {
  erro: { bg: 'var(--renea-erro-bg)', cor: 'var(--renea-erro)' },
  sucesso: { bg: 'var(--renea-sucesso-bg)', cor: 'var(--renea-sucesso)' },
  aviso: { bg: 'var(--renea-aviso-bg)', cor: 'var(--renea-aviso)' },
  info: { bg: 'var(--renea-verde-claro-bg)', cor: 'var(--renea-verde-institucional)' },
};

/**
 * @param {'erro' | 'sucesso' | 'aviso' | 'info'} tipo
 */
export default function Alert({ tipo = 'info', children }) {
  const estilo = ESTILOS[tipo] || ESTILOS.info;

  return (
    <div
      role={tipo === 'erro' ? 'alert' : 'status'}
      style={{
        backgroundColor: estilo.bg,
        color: estilo.cor,
        padding: 'var(--renea-space-3) var(--renea-space-4)',
        borderRadius: 'var(--renea-radius-md)',
        fontSize: 'var(--renea-fs-sm)',
        fontWeight: 500,
        lineHeight: 1.4,
      }}
    >
      {children}
    </div>
  );
}
