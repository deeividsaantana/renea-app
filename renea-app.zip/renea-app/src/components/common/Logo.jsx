// src/components/common/Logo.jsx
//
// Componente central do logo. Escolhe automaticamente a versão correta do
// SVG conforme a superfície de fundo, seguindo a tabela da seção 2.1 da
// especificação técnica:
//   - fundo escuro/verde -> logo-renea-original.svg (texto branco)
//   - fundo claro/branco -> logo-renea-fundo-claro.svg (texto verde escuro)
//
// NUNCA usar a versão "original" (texto branco) sobre fundo branco.

import logoOriginal from '../../assets/logo/logo-renea-original.svg';
import logoFundoClaro from '../../assets/logo/logo-renea-fundo-claro.svg';

/**
 * @param {'claro' | 'escuro'} fundo - tipo de superfície onde o logo será exibido
 * @param {number} altura - altura do logo em px (largura é proporcional)
 * @param {string} className - classes CSS adicionais
 */
export default function Logo({ fundo = 'claro', altura = 36, className = '' }) {
  const src = fundo === 'escuro' ? logoOriginal : logoFundoClaro;
  const alt = 'Renea Infraestrutura';

  return (
    <img
      src={src}
      alt={alt}
      style={{ height: altura, width: 'auto', display: 'block' }}
      className={className}
    />
  );
}
