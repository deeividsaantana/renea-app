// src/components/auth/RotaProtegida.jsx
//
// Guarda de rota: redireciona para /login se não houver usuário autenticado,
// e opcionalmente restringe a rota a um perfil específico (ex: somente admin).

import { Navigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import LoadingScreen from '../common/LoadingScreen';

/**
 * @param {React.ReactNode} children
 * @param {'admin'} [somenteAdmin] - se true, exige perfil admin
 */
export default function RotaProtegida({ children, somenteAdmin = false }) {
  const { carregando, logado, isAdmin, isAtivo } = useAuth();

  if (carregando) {
    return <LoadingScreen />;
  }

  if (!logado) {
    return <Navigate to="/login" replace />;
  }

  if (!isAtivo) {
    return <Navigate to="/login" replace state={{ desativado: true }} />;
  }

  if (somenteAdmin && !isAdmin) {
    return <Navigate to="/" replace />;
  }

  return children;
}
