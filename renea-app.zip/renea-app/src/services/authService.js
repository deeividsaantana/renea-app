// src/services/authService.js
//
// Camada de autenticação. Implementa as regras da seção 3.2 e 3.3 da
// especificação técnica:
//  - mensagem genérica de erro (nunca revela se o e-mail existe);
//  - bloqueio temporário após 5 tentativas erradas consecutivas;
//  - fluxo de recuperação de senha com mensagem neutra.
//
// O controle de tentativas é feito no localStorage por enquanto (client-side).
// Para um bloqueio robusto contra múltiplos dispositivos/navegadores, o ideal
// futuro é mover essa contagem para uma Cloud Function ou Firestore, mas isso
// cobre o requisito funcional descrito na especificação para a Fase 2.

import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth } from '../config/firebase';
import { LOGIN_MAX_TENTATIVAS, LOGIN_BLOQUEIO_MINUTOS } from '../config/constants';

const CHAVE_TENTATIVAS = 'renea_login_tentativas';

function lerTentativas(email) {
  try {
    const dados = JSON.parse(localStorage.getItem(CHAVE_TENTATIVAS) || '{}');
    return dados[email.toLowerCase()] || { contagem: 0, bloqueadoAte: null };
  } catch {
    return { contagem: 0, bloqueadoAte: null };
  }
}

function salvarTentativas(email, registro) {
  try {
    const dados = JSON.parse(localStorage.getItem(CHAVE_TENTATIVAS) || '{}');
    dados[email.toLowerCase()] = registro;
    localStorage.setItem(CHAVE_TENTATIVAS, JSON.stringify(dados));
  } catch {
    // localStorage indisponível (modo privado, etc.) — segue sem bloqueio local
  }
}

function limparTentativas(email) {
  try {
    const dados = JSON.parse(localStorage.getItem(CHAVE_TENTATIVAS) || '{}');
    delete dados[email.toLowerCase()];
    localStorage.setItem(CHAVE_TENTATIVAS, JSON.stringify(dados));
  } catch {
    // ignora
  }
}

/**
 * Verifica se o e-mail está temporariamente bloqueado por excesso de tentativas.
 * Retorna { bloqueado: boolean, minutosRestantes: number }
 */
export function verificarBloqueio(email) {
  const registro = lerTentativas(email);

  if (registro.bloqueadoAte && Date.now() < registro.bloqueadoAte) {
    const minutosRestantes = Math.ceil((registro.bloqueadoAte - Date.now()) / 60000);
    return { bloqueado: true, minutosRestantes };
  }

  return { bloqueado: false, minutosRestantes: 0 };
}

/**
 * Realiza o login. Lança erro com mensagem já tratada para exibição direta na UI.
 */
export async function login(email, senha) {
  const emailNormalizado = email.trim().toLowerCase();

  const statusBloqueio = verificarBloqueio(emailNormalizado);
  if (statusBloqueio.bloqueado) {
    throw new Error(
      `Muitas tentativas incorretas. Tente novamente em ${statusBloqueio.minutosRestantes} minuto(s).`
    );
  }

  try {
    const credencial = await signInWithEmailAndPassword(auth, emailNormalizado, senha);
    limparTentativas(emailNormalizado);
    return credencial.user;
  } catch (erro) {
    // Códigos do Firebase Auth que indicam credencial inválida.
    const codigosCredencialInvalida = [
      'auth/wrong-password',
      'auth/user-not-found',
      'auth/invalid-credential',
      'auth/invalid-email',
    ];

    if (codigosCredencialInvalida.includes(erro.code)) {
      const registro = lerTentativas(emailNormalizado);
      const novaContagem = registro.contagem + 1;

      if (novaContagem >= LOGIN_MAX_TENTATIVAS) {
        const bloqueadoAte = Date.now() + LOGIN_BLOQUEIO_MINUTOS * 60 * 1000;
        salvarTentativas(emailNormalizado, { contagem: novaContagem, bloqueadoAte });
        throw new Error(
          `Muitas tentativas incorretas. Login bloqueado por ${LOGIN_BLOQUEIO_MINUTOS} minutos.`
        );
      }

      salvarTentativas(emailNormalizado, { contagem: novaContagem, bloqueadoAte: null });

      // Mensagem genérica — nunca revela se o e-mail existe na base.
      throw new Error('Usuário ou senha incorretos.');
    }

    if (erro.code === 'auth/too-many-requests') {
      throw new Error('Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.');
    }

    if (erro.code === 'auth/user-disabled') {
      throw new Error('Este usuário está desativado. Procure um administrador.');
    }

    // Erro inesperado (rede, configuração, etc.)
    throw new Error('Não foi possível entrar agora. Tente novamente em instantes.');
  }
}

export async function logout() {
  await firebaseSignOut(auth);
}

/**
 * Envia e-mail de redefinição de senha. Sempre retorna sucesso do ponto de
 * vista da UI — a mensagem de confirmação é neutra independentemente de o
 * e-mail existir, conforme a especificação (seção 3.3).
 */
export async function solicitarRedefinicaoSenha(email) {
  const emailNormalizado = email.trim().toLowerCase();

  try {
    await sendPasswordResetEmail(auth, emailNormalizado);
  } catch (erro) {
    // auth/user-not-found não deve mudar a resposta visível ao usuário.
    if (erro.code !== 'auth/user-not-found' && erro.code !== 'auth/invalid-email') {
      console.error('Erro ao solicitar redefinição de senha:', erro);
    }
  }

  // Mensagem sempre neutra, independente do resultado real.
  return 'Se o e-mail estiver cadastrado, você receberá as instruções em instantes.';
}
