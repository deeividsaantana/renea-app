// src/config/firebase.js
//
// Configuração central do Firebase (Auth + Firestore) para o Renea Infraestrutura.
//
// COMO PREENCHER:
// 1. No console do Firebase (https://console.firebase.google.com), abra o projeto
//    NOVO do Renea (não o antigo com workspaces/funcionarios/registros).
// 2. Ícone de engrenagem > Configurações do projeto > aba Geral > "Seus aplicativos"
// 3. Registre (ou abra) o app Web e copie o bloco firebaseConfig.
// 4. Substitua os valores abaixo.
//
// Por segurança, em produção prefira variáveis de ambiente (.env) ao invés de
// valores hardcoded — veja o arquivo .env.example na raiz do projeto.

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'COLE_AQUI_SUA_API_KEY',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'seu-projeto.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'seu-projeto',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'seu-projeto.appspot.com',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '000000000000',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:000000000000:web:0000000000000000000000',
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);

export default app;
