// src/config/constants.js
//
// Constantes centrais do sistema, derivadas da especificação técnica
// (seção 4 — Modelo de dados). Mudar nomes de coleção aqui reflete em
// todo o app — não duplicar essas strings em outros arquivos.

export const COLLECTIONS = {
  LANCAMENTOS: 'lancamentos',
  FROTAS: 'frotas',
  EMPRESAS: 'empresas',
  TIPOS_COMBUSTIVEL: 'tiposCombustivel',
  COMBOIOS: 'comboios',
  USUARIOS: 'usuarios',
};

export const PERFIS = {
  ADMIN: 'admin',
  OPERADOR: 'operador',
};

export const PERFIL_LABELS = {
  [PERFIS.ADMIN]: 'Administrador',
  [PERFIS.OPERADOR]: 'Operador',
};

// Regras de bloqueio de login (seção 3.2 da especificação)
export const LOGIN_MAX_TENTATIVAS = 5;
export const LOGIN_BLOQUEIO_MINUTOS = 15;

// Tipos de equipamento sugeridos para o cadastro de frotas (seção 4.2)
export const TIPOS_FROTA_SUGERIDOS = [
  'Caminhão',
  'Gerador',
  'Perfuratriz',
  'Escavadeira',
  'Outro',
];
