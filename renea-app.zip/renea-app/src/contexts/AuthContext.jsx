// src/contexts/AuthContext.jsx
//
// Contexto de autenticação. Mantém o usuário logado (Firebase Auth) e o
// respectivo documento de perfil (coleção `usuarios`, que define admin/operador).
//
// Qualquer componente pode consumir via o hook useAuth().

import { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../config/firebase';
import { COLLECTIONS, PERFIS } from '../config/constants';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuarioAuth, setUsuarioAuth] = useState(null); // objeto do Firebase Auth
  const [perfilUsuario, setPerfilUsuario] = useState(null); // documento da coleção `usuarios`
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUsuarioAuth(user);

      if (user) {
        try {
          const refUsuario = doc(db, COLLECTIONS.USUARIOS, user.uid);
          const snapUsuario = await getDoc(refUsuario);

          if (snapUsuario.exists()) {
            setPerfilUsuario({ id: snapUsuario.id, ...snapUsuario.data() });
          } else {
            // Usuário existe no Auth mas não tem documento de perfil —
            // situação anômala (ex: criado direto no console do Firebase).
            setPerfilUsuario(null);
          }
        } catch (erro) {
          console.error('Erro ao carregar perfil do usuário:', erro);
          setPerfilUsuario(null);
        }
      } else {
        setPerfilUsuario(null);
      }

      setCarregando(false);
    });

    return unsubscribe;
  }, []);

  const isAdmin = perfilUsuario?.perfil === PERFIS.ADMIN;
  const isOperador = perfilUsuario?.perfil === PERFIS.OPERADOR;
  const isAtivo = perfilUsuario?.ativo !== false;

  const value = {
    usuarioAuth,
    perfilUsuario,
    carregando,
    isAdmin,
    isOperador,
    isAtivo,
    logado: !!usuarioAuth && !!perfilUsuario,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
}
