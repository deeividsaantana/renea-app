// src/App.jsx
//
// Raiz da aplicação: provedores de contexto + roteamento.

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import RotaProtegida from './components/auth/RotaProtegida';
import AppLayout from './components/layout/AppLayout';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import NovoLancamento from './pages/NovoLancamento';
import Relatorios from './pages/Relatorios';
import Administracao from './pages/Administracao';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route
            path="/"
            element={
              <RotaProtegida>
                <AppLayout>
                  <Dashboard />
                </AppLayout>
              </RotaProtegida>
            }
          />

          <Route
            path="/lancamento"
            element={
              <RotaProtegida>
                <AppLayout>
                  <NovoLancamento />
                </AppLayout>
              </RotaProtegida>
            }
          />

          <Route
            path="/relatorios"
            element={
              <RotaProtegida>
                <AppLayout>
                  <Relatorios />
                </AppLayout>
              </RotaProtegida>
            }
          />

          <Route
            path="/administracao"
            element={
              <RotaProtegida somenteAdmin>
                <AppLayout>
                  <Administracao />
                </AppLayout>
              </RotaProtegida>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
