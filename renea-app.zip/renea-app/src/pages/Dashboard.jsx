// src/pages/Dashboard.jsx
//
// Painel principal. Nesta Fase 1, exibe a estrutura visual e atalhos.
// Os cartões de resumo (litros do dia/mês, lançamentos, alertas) serão
// conectados a dados reais do Firestore na Fase 3, quando o formulário de
// lançamento estiver gravando registros.

import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';

function CartaoResumo({ titulo, valor, descricao }) {
  return (
    <Card>
      <p style={{ fontSize: 'var(--renea-fs-sm)', color: 'var(--renea-texto-secundario)', marginBottom: 'var(--renea-space-2)' }}>
        {titulo}
      </p>
      <p style={{ fontSize: 'var(--renea-fs-2xl)', fontWeight: 700, color: 'var(--renea-verde-institucional)' }}>
        {valor}
      </p>
      {descricao && (
        <p style={{ fontSize: 'var(--renea-fs-xs)', color: 'var(--renea-texto-secundario)', marginTop: 'var(--renea-space-1)' }}>
          {descricao}
        </p>
      )}
    </Card>
  );
}

export default function Dashboard() {
  const { perfilUsuario } = useAuth();
  const navigate = useNavigate();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-6)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 'var(--renea-space-4)' }}>
        <div>
          <h1 style={{ fontSize: 'var(--renea-fs-xl)' }}>
            Olá, {perfilUsuario?.nome?.split(' ')[0] || 'bem-vindo'}
          </h1>
          <p style={{ color: 'var(--renea-texto-secundario)', marginTop: 'var(--renea-space-1)' }}>
            Resumo do abastecimento da frota Renea Infraestrutura.
          </p>
        </div>
        <Button onClick={() => navigate('/lancamento')}>+ Novo lançamento</Button>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: 'var(--renea-space-5)',
        }}
      >
        <CartaoResumo titulo="Litros hoje" valor="—" descricao="Conectar ao Firestore na Fase 3" />
        <CartaoResumo titulo="Litros no mês" valor="—" descricao="Conectar ao Firestore na Fase 3" />
        <CartaoResumo titulo="Lançamentos hoje" valor="—" descricao="Conectar ao Firestore na Fase 3" />
        <CartaoResumo titulo="Alertas" valor="—" descricao="Equipamentos sem lançamento recente" />
      </div>
    </div>
  );
}
