// src/pages/Login.jsx

import { useState } from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import Logo from '../components/common/Logo';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';
import Card from '../components/common/Card';
import { login, solicitarRedefinicaoSenha } from '../services/authService';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { logado, carregando: carregandoAuth } = useAuth();

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  const [modoRecuperacao, setModoRecuperacao] = useState(false);
  const [emailRecuperacao, setEmailRecuperacao] = useState('');
  const [mensagemRecuperacao, setMensagemRecuperacao] = useState('');
  const [enviandoRecuperacao, setEnviandoRecuperacao] = useState(false);

  const contaDesativada = location.state?.desativado;

  // Já logado? não faz sentido mostrar a tela de login.
  if (!carregandoAuth && logado) {
    return <Navigate to="/" replace />;
  }

  async function handleLogin(evento) {
    evento.preventDefault();
    setErro('');

    if (!email || !senha) {
      setErro('Informe e-mail e senha.');
      return;
    }

    setEnviando(true);
    try {
      await login(email, senha);
      navigate('/', { replace: true });
    } catch (e) {
      setErro(e.message);
    } finally {
      setEnviando(false);
    }
  }

  async function handleRecuperarSenha(evento) {
    evento.preventDefault();
    setMensagemRecuperacao('');

    if (!emailRecuperacao) {
      return;
    }

    setEnviandoRecuperacao(true);
    try {
      const mensagem = await solicitarRedefinicaoSenha(emailRecuperacao);
      setMensagemRecuperacao(mensagem);
    } finally {
      setEnviandoRecuperacao(false);
    }
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--renea-verde-institucional)',
        padding: 'var(--renea-space-5)',
      }}
    >
      <div style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 'var(--renea-space-6)' }}>
          {/* Fundo verde -> usar logo original (texto branco) */}
          <Logo fundo="escuro" altura={48} />
        </div>

        <Card>
          {contaDesativada && (
            <div style={{ marginBottom: 'var(--renea-space-4)' }}>
              <Alert tipo="aviso">Sua conta está desativada. Procure um administrador.</Alert>
            </div>
          )}

          {!modoRecuperacao ? (
            <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-4)' }}>
              <h1 style={{ fontSize: 'var(--renea-fs-lg)', marginBottom: 'var(--renea-space-2)' }}>
                Entrar
              </h1>

              <Input
                label="E-mail"
                type="email"
                autoComplete="email"
                placeholder="seuemail@empresa.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={enviando}
              />

              <Input
                label="Senha"
                type="password"
                autoComplete="current-password"
                placeholder="••••••••"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                disabled={enviando}
              />

              {erro && <Alert tipo="erro">{erro}</Alert>}

              <Button type="submit" carregando={enviando} style={{ marginTop: 'var(--renea-space-2)' }}>
                Entrar
              </Button>

              <button
                type="button"
                onClick={() => {
                  setModoRecuperacao(true);
                  setEmailRecuperacao(email);
                  setErro('');
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--renea-verde-institucional)',
                  fontSize: 'var(--renea-fs-sm)',
                  fontWeight: 600,
                  cursor: 'pointer',
                  textAlign: 'center',
                  padding: 'var(--renea-space-2)',
                }}
              >
                Esqueci minha senha
              </button>
            </form>
          ) : (
            <form
              onSubmit={handleRecuperarSenha}
              style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-4)' }}
            >
              <h1 style={{ fontSize: 'var(--renea-fs-lg)', marginBottom: 'var(--renea-space-2)' }}>
                Recuperar senha
              </h1>
              <p style={{ fontSize: 'var(--renea-fs-sm)', color: 'var(--renea-texto-secundario)' }}>
                Informe seu e-mail cadastrado. Enviaremos um link para você definir uma nova senha.
              </p>

              <Input
                label="E-mail"
                type="email"
                autoComplete="email"
                placeholder="seuemail@empresa.com"
                value={emailRecuperacao}
                onChange={(e) => setEmailRecuperacao(e.target.value)}
                disabled={enviandoRecuperacao}
              />

              {mensagemRecuperacao && <Alert tipo="sucesso">{mensagemRecuperacao}</Alert>}

              <Button type="submit" carregando={enviandoRecuperacao}>
                Enviar instruções
              </Button>

              <button
                type="button"
                onClick={() => {
                  setModoRecuperacao(false);
                  setMensagemRecuperacao('');
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--renea-texto-secundario)',
                  fontSize: 'var(--renea-fs-sm)',
                  fontWeight: 600,
                  cursor: 'pointer',
                  textAlign: 'center',
                  padding: 'var(--renea-space-2)',
                }}
              >
                Voltar para o login
              </button>
            </form>
          )}
        </Card>
      </div>
    </div>
  );
}
