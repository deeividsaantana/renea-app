// src/pages/Administracao.jsx
//
// Painel de administração. Nesta Fase 1, apenas a estrutura visual e as
// abas. Criação/edição de usuários (Fase 2) e gestão de cadastros
// auxiliares (Fase 3) serão implementadas nas próximas fases.

import { useState } from 'react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';

const ABAS = [
  { id: 'usuarios', label: 'Usuários' },
  { id: 'frotas', label: 'Frotas' },
  { id: 'empresas', label: 'Empresas' },
  { id: 'combustiveis', label: 'Tipos de combustível' },
  { id: 'comboios', label: 'Comboios' },
];

export default function Administracao() {
  const [abaAtiva, setAbaAtiva] = useState('usuarios');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-5)' }}>
      <div>
        <h1 style={{ fontSize: 'var(--renea-fs-xl)' }}>Administração</h1>
        <p style={{ color: 'var(--renea-texto-secundario)', marginTop: 'var(--renea-space-1)' }}>
          Gerencie usuários e cadastros auxiliares do sistema.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 'var(--renea-space-2)', borderBottom: '1px solid var(--renea-cinza-borda)' }}>
        {ABAS.map((aba) => (
          <button
            key={aba.id}
            onClick={() => setAbaAtiva(aba.id)}
            style={{
              background: 'none',
              border: 'none',
              borderBottom: abaAtiva === aba.id ? '2px solid var(--renea-verde-institucional)' : '2px solid transparent',
              color: abaAtiva === aba.id ? 'var(--renea-verde-institucional)' : 'var(--renea-texto-secundario)',
              fontWeight: 600,
              fontSize: 'var(--renea-fs-sm)',
              padding: 'var(--renea-space-3) var(--renea-space-4)',
              cursor: 'pointer',
            }}
          >
            {aba.label}
          </button>
        ))}
      </div>

      <Alert tipo="info">
        {abaAtiva === 'usuarios'
          ? 'Criação, edição de perfil, ativação/desativação e reset de senha de usuários entram na Fase 2.'
          : 'Gestão deste cadastro auxiliar entra na Fase 3, junto com o formulário de lançamento.'}
      </Alert>

      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--renea-space-4)' }}>
          <h2 style={{ fontSize: 'var(--renea-fs-md)' }}>
            {ABAS.find((a) => a.id === abaAtiva)?.label}
          </h2>
          <Button disabled>+ Novo</Button>
        </div>

        <div
          style={{
            border: '1px dashed var(--renea-cinza-borda)',
            borderRadius: 'var(--renea-radius-md)',
            padding: 'var(--renea-space-7)',
            textAlign: 'center',
            color: 'var(--renea-texto-secundario)',
          }}
        >
          A listagem aparecerá aqui nas próximas fases.
        </div>
      </Card>
    </div>
  );
}
