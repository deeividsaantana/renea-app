// src/pages/NovoLancamento.jsx
//
// Formulário de novo lançamento de abastecimento. Nesta Fase 1, apenas a
// estrutura visual e os campos estão presentes. Autocomplete de frota,
// cálculo automático de litros, validação de km/horímetro e gravação real
// no Firestore entram na Fase 3, conforme combinado.

import Card from '../components/common/Card';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';

export default function NovoLancamento() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-5)', maxWidth: 720 }}>
      <div>
        <h1 style={{ fontSize: 'var(--renea-fs-xl)' }}>Novo lançamento</h1>
        <p style={{ color: 'var(--renea-texto-secundario)', marginTop: 'var(--renea-space-1)' }}>
          Registre um abastecimento de equipamento da frota.
        </p>
      </div>

      <Alert tipo="info">
        Formulário em construção — autocomplete de frota, cálculo automático de litros e
        validações entram na Fase 3.
      </Alert>

      <Card>
        <form style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-4)' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 'var(--renea-space-4)' }}>
            <Input label="Data" type="date" disabled />
            <Input label="Hora" type="time" disabled />
          </div>

          <Input label="Frota" placeholder="Código ou descrição do equipamento" disabled />
          <Input label="Descrição" placeholder="Preenchido automaticamente" disabled />

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 'var(--renea-space-4)' }}>
            <Input label="Km inicial" type="number" disabled />
            <Input label="Horímetro inicial" type="number" disabled />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 'var(--renea-space-4)' }}>
            <Input label="Início da bomba" type="number" disabled />
            <Input label="Fim da bomba" type="number" disabled />
            <Input label="Litros" type="number" placeholder="Calculado automaticamente" disabled />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 'var(--renea-space-4)' }}>
            <Input label="Comboio" placeholder="Identificação do comboio" disabled />
            <Input label="Tipo de combustível" placeholder="Ex.: Óleo Diesel S10" disabled />
            <Input label="Empresa" placeholder="Empresa proprietária do equipamento" disabled />
          </div>

          <div style={{ display: 'flex', gap: 'var(--renea-space-3)', marginTop: 'var(--renea-space-2)' }}>
            <Button disabled>Salvar</Button>
            <Button variante="secundario" disabled>
              Salvar e lançar próximo
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
