// src/pages/Relatorios.jsx
//
// Tela de relatórios. Nesta Fase 1, apenas a estrutura visual. Filtros
// combináveis, totais recalculados e exportação PDF/Excel entram na Fase 4.

import Card from '../components/common/Card';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';

export default function Relatorios() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--renea-space-5)' }}>
      <div>
        <h1 style={{ fontSize: 'var(--renea-fs-xl)' }}>Relatórios</h1>
        <p style={{ color: 'var(--renea-texto-secundario)', marginTop: 'var(--renea-space-1)' }}>
          Consulte e exporte os lançamentos de abastecimento.
        </p>
      </div>

      <Alert tipo="info">
        Filtros, totais e exportação em PDF/Excel entram na Fase 4.
      </Alert>

      <Card>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
            gap: 'var(--renea-space-4)',
            marginBottom: 'var(--renea-space-5)',
          }}
        >
          <Input label="De" type="date" disabled />
          <Input label="Até" type="date" disabled />
          <Input label="Frota" placeholder="Todas" disabled />
          <Input label="Empresa" placeholder="Todas" disabled />
          <Input label="Comboio" placeholder="Todos" disabled />
        </div>

        <div style={{ display: 'flex', gap: 'var(--renea-space-3)', marginBottom: 'var(--renea-space-5)' }}>
          <Button disabled>Filtrar</Button>
          <Button variante="secundario" disabled>
            Exportar PDF
          </Button>
          <Button variante="secundario" disabled>
            Exportar Excel/CSV
          </Button>
        </div>

        <div
          style={{
            border: '1px dashed var(--renea-cinza-borda)',
            borderRadius: 'var(--renea-radius-md)',
            padding: 'var(--renea-space-7)',
            textAlign: 'center',
            color: 'var(--renea-texto-secundario)',
          }}
        >
          A tabela de resultados aparecerá aqui na Fase 4.
        </div>
      </Card>
    </div>
  );
}
