# Renea Infraestrutura — Sistema de Gestão de Frota e Abastecimento

Sistema web para substituir o controle manual em planilha do abastecimento
da frota da Renea Infraestrutura. Stack: React + Firebase (Auth +
Firestore) + Netlify.

Este projeto segue a especificação técnica (`Renea_Especificacao_Tecnica.docx`)
como fonte da verdade. Veja o documento para o modelo de dados completo,
regras de negócio e fases de desenvolvimento.

## Status atual: Fase 1 — Estrutura base

O que já está pronto nesta fase:

- ✅ Projeto React (Vite) criado e organizado
- ✅ Identidade visual aplicada (cores, logo, favicon)
- ✅ Estrutura de rotas e telas (Login, Painel, Lançamento, Relatórios, Administração)
- ✅ Contexto de autenticação (`AuthContext`) pronto para conectar ao Firebase
- ✅ Serviço de login com regras de bloqueio e mensagens neutras (seção 3.2/3.3)
- ✅ Regras de segurança do Firestore (`firestore.rules`)
- ⏳ Conexão real com o Firebase: falta preencher as credenciais (veja abaixo)
- ⏳ Deploy no Netlify: ainda não realizado

O que entra nas próximas fases (conforme combinado):

- **Fase 2** — autenticação completa testada de ponta a ponta, criação de usuários pelo admin
- **Fase 3** — formulário de lançamento com autocomplete, validações e cadastros auxiliares
- **Fase 4** — relatórios com filtros, totais e exportação PDF/Excel

## Como rodar localmente

### 1. Instalar dependências

```bash
npm install
```

### 2. Configurar o Firebase

Copie o arquivo de exemplo:

```bash
cp .env.example .env
```

Abra o `.env` e preencha com as credenciais do projeto Firebase **novo**
do Renea (Configurações do projeto > Geral > Seus aplicativos > app Web):

```
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=...
VITE_FIREBASE_PROJECT_ID=...
VITE_FIREBASE_STORAGE_BUCKET=...
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
```

No console do Firebase, confirme também que:

- **Authentication > Sign-in method > E-mail/senha** está habilitado
- **Firestore Database** já foi criado

### 3. Criar o primeiro usuário admin (manual, uma única vez)

Como não existe autocadastro, o primeiro admin precisa ser criado
manualmente direto no console do Firebase, antes de qualquer pessoa
conseguir usar o sistema:

1. **Authentication > Users > Add user** — crie com e-mail e senha
2. Copie o **UID** gerado
3. **Firestore Database > Start collection** → nome `usuarios`
4. ID do documento = o UID copiado
5. Campos do documento:
   - `nome` (string): seu nome
   - `email` (string): o mesmo e-mail usado no Authentication
   - `perfil` (string): `admin`
   - `ativo` (boolean): `true`
   - `criadoPor` (string): pode deixar `"sistema"` para o primeiro admin

Depois desse primeiro admin existir, ele já poderá criar os demais
usuários pela tela de Administração (a partir da Fase 2).

### 4. Publicar as regras de segurança do Firestore

Usando o [Firebase CLI](https://firebase.google.com/docs/cli):

```bash
firebase login
firebase use --add        # selecione o projeto novo do Renea
firebase deploy --only firestore:rules
```

Ou cole o conteúdo de `firestore.rules` diretamente em
**Firestore Database > Regras** no console.

### 5. Rodar o projeto

```bash
npm run dev
```

Acesse `http://localhost:5173` e faça login com o admin criado no passo 3.

## Deploy no Netlify

1. Suba este projeto para um repositório Git (GitHub, GitLab, etc.)
2. No Netlify: **Add new site > Import an existing project**
3. Configurações de build:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Em **Site settings > Environment variables**, adicione as mesmas
   variáveis do `.env` (todas com prefixo `VITE_`)
5. Deploy

## Estrutura de pastas

```
src/
├── assets/logo/        # Logos oficiais (SVG)
├── components/
│   ├── auth/            # RotaProtegida (guarda de rota)
│   ├── common/           # Button, Input, Card, Alert, Logo, LoadingScreen
│   └── layout/           # Navbar, AppLayout
├── config/
│   ├── firebase.js       # Inicialização do Firebase
│   └── constants.js      # Nomes de coleções, perfis, regras de negócio
├── contexts/
│   └── AuthContext.jsx   # Estado global de autenticação
├── pages/                # Login, Dashboard, NovoLancamento, Relatorios, Administracao
├── services/
│   └── authService.js    # Login, logout, recuperação de senha, bloqueio
└── styles/
    ├── tokens.css         # Paleta de cores, tipografia, espaçamento
    └── global.css         # Reset e estilos base
```

## Identidade visual

| Uso | Cor | Código |
|---|---|---|
| Verde do ícone (logo) | Verde marca | `#22A45A` |
| Verde institucional (texto/primária) | Verde escuro | `#0F5C36` |
| Verde de destaque/hover | Verde médio | `#2E9E63` |
| Fundo de destaque suave | Verde claríssimo | `#EAF6EF` |

Logos: `logo-renea-original.svg` (texto branco, usar em fundo verde/escuro)
e `logo-renea-fundo-claro.svg` (texto verde escuro, usar em fundo
branco/claro — inclusive no cabeçalho dos relatórios PDF).
